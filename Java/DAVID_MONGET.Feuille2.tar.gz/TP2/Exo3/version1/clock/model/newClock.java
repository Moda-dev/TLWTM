public class NewClock
