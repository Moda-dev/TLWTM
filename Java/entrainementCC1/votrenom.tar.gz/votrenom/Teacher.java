/**
 *
 * @author votre_nom
 */
public class Teacher {
    
    
    public Teacher(String[] firstName, String lastName){
    }
    
    
    @Override
    public String toString(){
    
    }
}
