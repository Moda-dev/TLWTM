/**
 *
 * @author votre_nom
 */
public class Slot  {
    
    public Slot(Topic topic, Teacher teacher, int slotType, int duration){

    }

    public Slot(Topic topic, Teacher teacher, int slotType){

    } 
    
    @Override
    public String toString(){
    
    }
   
    

    public static void main(String[] args){
        String[] jrr_name = {"John", "Ronald","Reuel"};
        Teacher  jrr = new Teacher(jrr_name, "Tolkien");
        
        Topic lotr = new Topic("Lord of the rings", 
                "One Ring to rule them all,\n"
                + "One Ring to find them, "
                + "\nOne Ring to bring them all \nand "
                + "in the darkness bind them");
        
        Slot s = new Slot(lotr,jrr,Slot.TD);
        
        
        System.out.println(jrr);
        System.out.println("*************************");
        System.out.println(lotr);
        System.out.println("*************************");
        System.out.println(s);
        System.out.println("*************************");
    }


}
