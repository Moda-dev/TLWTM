/**
 *
 * @author votre_nom 
 */

public class Topic {
       
    public Topic(String title, String description){

    }
    
    
    @Override
    public String toString(){
	
    }
}
